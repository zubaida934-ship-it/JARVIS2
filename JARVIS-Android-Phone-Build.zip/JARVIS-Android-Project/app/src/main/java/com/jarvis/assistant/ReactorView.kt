package com.jarvis.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.animation.ValueAnimator
import android.view.animation.LinearInterpolator

class ReactorView(context: Context) : View(context) {
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private var pulse = 0f

    init {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2600
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                pulse = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val base = minOf(width, height) * 0.39f
        val cyan = 0xFF36D9FF.toInt()
        val blue = 0xFF1677C8.toInt()

        for (i in 0..4) {
            val radius = base + i * 9f + pulse * 5f
            glow.color = if (i % 2 == 0) 0x1836D9FF else 0x101677C8
            glow.style = Paint.Style.FILL
            canvas.drawCircle(cx, cy, radius, glow)
        }

        line.color = cyan
        line.strokeWidth = 2.2f
        line.alpha = 210
        canvas.drawCircle(cx, cy, base + 25f, line)
        line.strokeWidth = 1.3f
        line.alpha = 150
        canvas.drawCircle(cx, cy, base + 12f, line)

        val oval = RectF(cx - base, cy - base, cx + base, cy + base)
        line.strokeWidth = 3f
        line.alpha = 230
        canvas.drawArc(oval, pulse * 360f, 105f, false, line)
        canvas.drawArc(oval, pulse * 360f + 180f, 70f, false, line)

        glow.style = Paint.Style.FILL
        glow.color = 0xFF0A3552.toInt()
        canvas.drawCircle(cx, cy, base - 7f, glow)
        line.color = cyan
        line.strokeWidth = 2.5f
        line.alpha = 255
        canvas.drawCircle(cx, cy, base - 7f, line)

        glow.color = 0xFF36D9FF.toInt()
        glow.setShadowLayer(28f, 0f, 0f, cyan)
        canvas.drawCircle(cx, cy, 9f + pulse * 2f, glow)
        glow.clearShadowLayer()
        glow.color = 0xFFB8F5FF.toInt()
        canvas.drawCircle(cx, cy, 4f, glow)

        val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = cyan
            strokeWidth = 2f
            alpha = 170
        }
        for (i in 0 until 48) {
            val angle = Math.toRadians(i * 7.5)
            val r1 = base + 32f
            val r2 = r1 + if (i % 4 == 0) 9f else 4f
            canvas.drawLine(
                cx + kotlin.math.cos(angle).toFloat() * r1,
                cy + kotlin.math.sin(angle).toFloat() * r1,
                cx + kotlin.math.cos(angle).toFloat() * r2,
                cy + kotlin.math.sin(angle).toFloat() * r2,
                tickPaint
            )
        }
    }
}
