package com.jarvis.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var speech: TextToSpeech
    private lateinit var status: TextView
    private lateinit var conversation: TextView
    private lateinit var input: EditText
    private var ttsReady = false

    private val cyan = Color.rgb(54, 217, 255)
    private val muted = Color.rgb(133, 178, 202)
    private val bg = Color.rgb(5, 11, 22)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        speech = TextToSpeech(this, this)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 18, 22, 18)
            setBackgroundColor(bg)
        }

        val top = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 25f
            letterSpacing = 0.24f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        page.addView(top, matchWrap())

        val subtitle = TextView(this).apply {
            text = "JUST A RATHER VERY INTELLIGENT SYSTEM"
            textSize = 9f
            letterSpacing = 0.13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, 5, 0, 5)
        }
        page.addView(subtitle, matchWrap())

        val reactor = ReactorView(this)
        val reactorParams = LinearLayout.LayoutParams(250, 250)
        reactorParams.topMargin = 12
        reactorParams.bottomMargin = 4
        page.addView(reactor, reactorParams)

        status = TextView(this).apply {
            text = "SYSTEM ONLINE  •  LOCAL DEMO"
            textSize = 11f
            letterSpacing = 0.12f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 12)
        }
        page.addView(status, matchWrap())

        conversation = TextView(this).apply {
            text = "Good evening. JARVIS interface is ready.\\n\\nNote: this starter build uses demo responses. Live AI connection is not configured yet."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(15, 14, 15, 14)
            background = rounded(Color.rgb(10, 25, 42), 18, Color.rgb(20, 91, 120))
        }
        val chatParams = LinearLayout.LayoutParams(-1, 0, 1f)
        chatParams.topMargin = 8
        chatParams.bottomMargin = 12
        page.addView(conversation, chatParams)

        input = EditText(this).apply {
            hint = "Ask JARVIS something..."
            setHintTextColor(muted)
            setTextColor(Color.WHITE)
            textSize = 15f
            singleLine = true
            setPadding(15, 11, 15, 11)
            background = rounded(Color.rgb(9, 22, 37), 16, Color.rgb(35, 121, 153))
        }
        page.addView(input, LinearLayout.LayoutParams(-1, 52))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 0)
        }
        val voice = makeButton("🎙  SPEAK", true)
        voice.setOnClickListener { startVoiceInput() }
        val send = makeButton("SEND  ➤", false)
        send.setOnClickListener { sendMessage() }
        val controlParams = LinearLayout.LayoutParams(0, 50, 1f)
        controlParams.marginEnd = 8
        controls.addView(voice, controlParams)
        val sendParams = LinearLayout.LayoutParams(0, 50, 1f)
        sendParams.marginStart = 8
        controls.addView(send, sendParams)
        page.addView(controls, matchWrap())

        val footer = TextView(this).apply {
            text = "VOICE INPUT • TEXT TO SPEECH • ANDROID"
            textSize = 9f
            letterSpacing = 0.1f
            setTextColor(Color.rgb(83, 125, 148))
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 0)
        }
        page.addView(footer, matchWrap())
        setContentView(page)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)

    private fun rounded(color: Int, radius: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(1, stroke)
        }

    private fun makeButton(label: String, outlined: Boolean): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            letterSpacing = 0.06f
            setTextColor(if (outlined) cyan else bg)
            background = rounded(if (outlined) Color.rgb(8, 25, 40) else cyan, 16,
                if (outlined) cyan else cyan)
            isAllCaps = false
        }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        addLine("YOU", message)
        input.setText("")
        val reply = demoReply(message)
        addLine("JARVIS", reply)
        speak(reply)
    }

    private fun addLine(who: String, message: String) {
        conversation.append("\\n\\n$who  ›  $message")
    }

    private fun demoReply(message: String): String {
        val q = message.lowercase(Locale.getDefault())
        return when {
            "time" in q -> "I cannot read your live clock in this demo build. Please check your phone's clock."
            "hello" in q || "hi" in q || "hey" in q -> "Hello. All systems are standing by. How may I assist?"
            "your name" in q -> "I am JARVIS, your personal assistant interface."
            "help" in q -> "I can demonstrate chat and voice controls. A secure AI service connection is the next upgrade."
            "thank" in q -> "Always a pleasure to assist."
            else -> "I have received your request. This is the offline starter version, so connect a secure AI backend to enable intelligent answers."
        }
    }

    private fun startVoiceInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
            }
            startActivityForResult(intent, 71)
        } catch (_: Exception) {
            status.text = "VOICE INPUT UNAVAILABLE ON THIS DEVICE"
        }
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 71 && resultCode == Activity.RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            input.setText(words?.firstOrNull() ?: "")
            input.setSelection(input.text.length)
            status.text = "VOICE CAPTURED  •  READY TO SEND"
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            ttsReady = speech.setLanguage(Locale.UK) != TextToSpeech.LANG_MISSING_DATA
        }
    }

    private fun speak(text: String) {
        if (ttsReady) speech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        if (::speech.isInitialized) {
            speech.stop()
            speech.shutdown()
        }
        super.onDestroy()
    }
}
