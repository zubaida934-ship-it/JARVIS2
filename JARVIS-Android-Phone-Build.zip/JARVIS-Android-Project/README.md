# JARVIS Android starter project

This is a native Android starter app with an Iron Man-inspired blue reactor interface.

## Included
- Animated blue reactor UI
- Text input and chat display
- Android speech recognition
- Text-to-speech replies
- Offline demo responses

## Important limitations
This first build is a working interface prototype, not a connected AI assistant yet. It does not have a live AI backend, persistent memory, wake-word listening, reminders, or broad phone automation. Those require additional services, permissions, and careful setup.

Do not put a private AI API key directly in the Android app. A production AI connection should use a secure backend that keeps the key off the phone.

## Build the APK using only an Android phone
This ZIP includes a GitHub Actions workflow for cloud building.

1. Create or sign in to a GitHub account in your phone browser.
2. Create a new repository named `JARVIS-Android-Project`. You can keep it private.
3. On the new repository page, choose **Add file > Upload files**.
4. Extract this ZIP on your phone using your file manager or an archive app.
5. Upload the CONTENTS of the extracted folder, including the hidden `.github` folder and its `workflows/build-apk.yml` file. If your file picker hides `.github`, use GitHub's web editor to create `.github/workflows/build-apk.yml` and paste the workflow from this ZIP's workflow file.
6. Commit the uploaded files.
7. Open the repository's **Actions** tab.
8. Select **Build JARVIS APK**, choose **Run workflow**, and confirm.
9. Wait for the workflow to finish successfully.
10. Open the completed run, scroll to **Artifacts**, and download `JARVIS-debug-APK`.
11. Extract the downloaded artifact ZIP. Tap `app-debug.apk` to install it. Android may ask you to allow installation from that browser or file manager; only enable this for the trusted file you just built, then turn it off again afterward.

## Build workflow
The workflow is at `.github/workflows/build-apk.yml`. It builds a debug APK on GitHub-hosted Ubuntu and uploads it as a downloadable artifact for 7 days.

## Permissions and compatibility
Minimum Android version: Android 6.0 (API 23). Target SDK: 35. Speech recognition uses the device's configured recognition provider and may require internet depending on the device and language.
